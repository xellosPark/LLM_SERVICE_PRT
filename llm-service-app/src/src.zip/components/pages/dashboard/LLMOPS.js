import React from 'react';
import './LLMOPS.css';

function LLMOPS() {
  return (
    <div className='llmops-content'>
      <div className="llmops-container" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '90%' }}>
        <h1>TBD</h1>
      </div>
    </div>

  );
}

export default LLMOPS;